<?php

/**
 * This is a part template
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;
?>

<!-- Ubiación -->
    <div>
        <div>
            <h3 class="text-center display-5" >Ubicación</h3>
            <img class="w-100" src="<?php the_field('mapa-ubicacion'); ?>">
        </div>
    </div>