<?php

/**
 * This is a part template
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;
?>

<!-- Video -->

        <!-- <h3 class="text-center display-5">Video</h3> -->
        <div id="video" class="sombra border border-5 border-light">
            <?php the_field('proyecto-video-embed'); ?>
        </div>

<!-- Fin video -->